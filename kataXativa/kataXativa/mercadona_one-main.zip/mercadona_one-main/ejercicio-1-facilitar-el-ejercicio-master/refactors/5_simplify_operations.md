**Podemos simplificar operaciones**

de esto:
```
item.quality = item.quality - 1;
...
item.quality = item.quality + 1;
...
item.quality = item.quality - item.quality;
```

```
item.quality -= 1;
...
item.quality += 1;
...
item.quality = 0;
```
