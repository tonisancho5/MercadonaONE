import unittest

from mercadona_shop_one import Item, MercadonaShopOne


class MercadonaShopOneTest(unittest.TestCase):

    def testFruitOneDayPast(self):
        pass

    def testFruitQualityLossTwiceAsFast(self):
        pass

    def testFruitQualityWillNeverBeNegative(self):
        pass

    def testFruitQualityWillNeverBeNegativeTwiceAsFast(self):
        pass

    def testAgedBlueCheeseQualityIncreasePerDay(self):
        pass

    def testAgedBlueCheeseQualityTopsAtFifty(self):
        pass

    def testIodizedSalt(self):
        pass

    def testHamBetweenThousandDaysAndElevenDaysBeforeTheEvent(self):
        pass

    def testHamBeforeTenDays(self):
        pass

    def testHamBetweenTenDaysAndSixDaysBeforeTheEvent(self):
        pass

    def testHamAtTenDaysAndSixDaysBeforeTheEvent(self):
        pass

    def testHamBetweenFiveDaysAndOneDayBeforeTheEvent(self):
        pass

    def testHamAtFiveDaysAndOneDayBeforeTheEvent(self):
        pass

    def testHamExpired(self):
        pass

    def testFrozenCakeOneDayPast(self):
        pass

    def testFrozenCakeQualityLossTwiceAsFast(self):
        pass

    def testFrozenCakeQualityWillNeverBeNegative(self):
        pass


if __name__ == '__main__':
    unittest.main()
