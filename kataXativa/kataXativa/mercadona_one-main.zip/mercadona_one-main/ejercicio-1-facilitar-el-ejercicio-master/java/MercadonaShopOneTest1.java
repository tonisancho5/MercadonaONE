package com.mercadona.hiring101;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MercadonaShopOneTest1 {

    @Test
    public void FruitOneDayPast() {

    }

    @Test
    public void FruitQualityLossTwiceAsFast() {

    }

    @Test
    public void FruitQualityWillNeverBeNegative() {

    }

    @Test
    public void FruitQualityWillNeverBeNegativeTwiceAsFast() {


    }

    @Test
    public void AgedBlueCheeseQualityIncreasePerDay() {

    }

    @Test
    public void AgedBlueCheeseQualityTopsAtFifty() {

    }

    @Test
    public void IodizedSalt() {

    }

    @Test
    public void HamBetweenThousandDaysAndElevenDaysBeforeTheEvent() {

    }

    @Test
    public void HamBeforeTenDays() {

    }

    @Test
    public void HamBetweenTenDaysAndSixDaysBeforeTheEvent() {

    }

    @Test
    public void HamAtTenDaysAndSixDaysBeforeTheEvent() {

    }

    @Test
    public void HamBetweenFiveDaysAndOneDayBeforeTheEvent() {

    }

    @Test
    public void HamAtFiveDaysAndOneDayBeforeTheEvent() {

    }

    @Test
    public void HamExpired() {

    }


}
