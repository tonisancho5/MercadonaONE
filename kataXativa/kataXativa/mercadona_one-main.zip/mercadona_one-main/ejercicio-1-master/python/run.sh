#!/bin/bash

venv/bin/python src/run.py $1
