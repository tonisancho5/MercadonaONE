    def testFruitOneDayPast():
        pass

    def testFruitQualityLossTwiceAsFast():
        pass

    def testFruitQualityWillNeverBeNegative():
        pass

    def testAgedBlueCheeseQualityIncreasePerDay():
        pass

    def testAgedBlueCheeseQualityTopsAtFifty():
        pass

    def testIodizedSalt():
        pass

    def testHamBetweenThousandDaysAndElevenDaysBeforeTheEvent():
        pass

    def testHamBeforeTenDays():
        pass

    def testHamBetweenTenDaysAndSixDaysBeforeTheEvent():
        pass

    def testHamAtTenDaysAndSixDaysBeforeTheEvent():
        pass

    def testHamBetweenFiveDaysAndOneDayBeforeTheEvent():
        pass

    def testHamAtFiveDaysAndOneDayBeforeTheEvent():
        pass

    def testHamExpired():
        pass

    def testFrozenCakeOneDayPast():
        pass

    def testFrozenCakeQualityLossTwiceAsFast():
        pass

    def testFrozenCakeQualityWillNeverBeNegative():
        pass
